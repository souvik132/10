const baileys = require('@whiskeysockets/baileys');
const makeWASocket = baileys.default;
const fs = require('fs');
const P = require('pino');

const { useSingleFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = baileys;
const { state, saveState } = useSingleFileAuthState('./auth_info.json');

const startSock = async () => {
    const { version } = await fetchLatestBaileysVersion();
    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        printQRInTerminal: true,
        auth: state
    });

    sock.ev.on('creds.update', saveState);

    sock.ev.on('connection.update', ({ connection }) => {
        if (connection === 'open') {
            console.log('✅ Bot connected');
        }
    });

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message) return;
        const text = msg.message.conversation || '';
        const from = msg.key.remoteJid;

        if (text === '.ping') {
            await sock.sendMessage(from, { text: 'pong!' });
        }
    });
};

startSock();
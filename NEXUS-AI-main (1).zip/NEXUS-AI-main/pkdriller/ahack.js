const {
  zokou
} = require("../framework/zokou");
zokou({
  'nomCom': "hack",
  'categorie': "Fun",
  'reaction': '⚡'
}, async (_0x31874c, _0x23f5d8, _0x2bf6f3) => {
  const {
    repondre: _0x988825,
    arg: _0x123444,
    prefixe: _0x1e90cb
  } = _0x2bf6f3;
  try {
    const _0x3c1805 = ["```⚡ *NEXUS-AI*  Injecting malware⚡```", "```🔐 *NEXUS-AI*  into device \n 0%```", "```♻️ transfering photos \n █ 10%```", "```♻️ transfer successful \n █ █ 20%```", "```♻️ transfering videos \n █ █ █ 30%```","```♻️ transfer successful \n █ █ █ █ 40%```","```♻️ transfering audio \n █ █ █ █ █ 50%```","```♻️ transfer successful \n █ █ █ █ █ █ 60%```","```♻️ transfering hidden files \n █ █ █ █ █ █ █ 70%```","```♻️ transfer successful \n █ █ █ █ █ █ █ █ 80%```","```♻️ transfering whatsapp chat \n █ █ █ █ █ █ █ █ █ 90%```","```♻️ transfer successful \n █ █ █ █ █ █ █ █ █ █ 100%```","```📲 System hyjacking on process.. \n Conecting to Server```","```🔌 Device successfully connected... \n Recieving data...```","```💡 Data hyjacked from divice 100% completed \n killing all evidence killing all malwares...```","```🔋 HACKING COMPLETED```","```📤 SENDING PHONE DOCUMENTS```"];
    for (const _0x4c7ce1 of _0x3c1805) {
      try {
        await _0x988825(_0x4c7ce1);
        await new Promise(_0x5458dc => setTimeout(_0x5458dc, 2000));
      } catch (_0x191491) {
        console.error("Error sending loading message:", _0x191491);
      }
    }
    const _0x452d = "```🗂️ ALL FILES TRANSFERRED```";
    try {
      await _0x988825(_0x452d);
    } catch (_0x3842d7) {
      console.error("Error sending prank message:", _0x3842d7);
      return await _0x988825("_🙏 An error occurred while sending the main prank message 🤨_");
    }
    const _0x5ed8e2 = ['10', '9', '8', '7', '6', '5', '4', '3', '2', '1'];
    for (const _0x30d275 of _0x5ed8e2) {
      try {
        await _0x988825("```❇️ SUCCESSFULLY SENT DATA AND Connection disconnected 📤```");
        await new Promise(_0x2364d6 => setTimeout(_0x2364d6, 1000));
      } catch (_0x298470) {
        console.error("Error during countdown:", _0x298470);
      }
    }
    try {
      await _0x988825("😏 *VICTIM SYSTEM DEMOLISHED!* 🤔");
    } catch (_0x34d0ce) {
      console.error("Error sending final message:", _0x34d0ce);
    }
  } catch (_0x3c8a28) {
    console.error("Critical error in prank script:", _0x3c8a28);
    return await _0x988825("_😊 A critical error occurred during the prank 🤗_");
  }
});
